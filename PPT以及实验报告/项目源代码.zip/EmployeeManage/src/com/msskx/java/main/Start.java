package com.msskx.java.main;

import com.msskx.java.view.LoginView;

public class Start {
    public static void main(String[] args) {
        new LoginView();
    }
}

package com.msskx.java.test;

import org.junit.Test;

public class TiktsTest {

}

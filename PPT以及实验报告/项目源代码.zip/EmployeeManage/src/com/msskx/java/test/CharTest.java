package com.msskx.java.test;

import org.junit.Test;

public class CharTest {
    @Test
    public void test(){
        String str="";
        char[] chars =str.toCharArray();
        System.out.println(chars.length);
    }
}

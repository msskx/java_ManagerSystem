package com.msskx.java.test;

import com.msskx.java.view.DataChart;
import org.junit.Test;

public class chartTest {
    @Test
    public void test(){
        new DataChart();
    }
}

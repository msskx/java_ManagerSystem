package com.msskx.java.test;

import com.msskx.java.view.MainView;
import org.junit.Test;

public class MainTest {
    @Test
    public void MainTest(){
        new MainView();
    }
}
